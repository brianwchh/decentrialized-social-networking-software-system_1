'use strict';

exports.rootname = 'brian';
exports.STATIC_ROOT = './public/static'