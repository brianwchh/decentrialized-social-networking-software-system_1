const ip='http://localhost:6464' ;
// const ip='http://192.168.11.127:6464' ;
const host='localhost';
// const host = '192.168.11.127' ;  // hackend server address 
const port='6464' ;

exports.ip = ip ;
exports.port = port ;
exports.host = host ;
