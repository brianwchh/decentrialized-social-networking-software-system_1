module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],

  // devServer: {
  //   proxy: {
  //     "/": {
  //       target: "http://52.79.86.10:8964",
  //       changeOrigin: true ,
  //       pathRewrite: {
  //         '^': ''
  //       }
  //     }
  //   }
  // }
}