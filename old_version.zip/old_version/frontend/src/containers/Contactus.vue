<template>
<div>
    <div style="margin-left: 2rem; margin-top:2rem;">
        <a href="https://github.com/brianwchh/decentrialized-social-networking-software-system_1" 
            >
            project github : https://github.com/brianwchh/decentrialized-social-networking-software-system_1
        </a>
    </div>
</div>

    
</template>

<script>
export default {

    name: "ContactUs",

    // data: ()=>{

    // }
}
</script>