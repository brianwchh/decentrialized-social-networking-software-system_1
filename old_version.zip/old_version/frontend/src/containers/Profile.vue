<template>
  <div> 
      <h1>hello profile</h1>
  </div>
</template>

<script>


export default {
  name: 'Profile',
  components: {
    
  }
}
</script>
