export const debug_ = true ;

// axios settings 
export const config_json = {
    headers: { 
      'Content-Type': 'application/json', 
    },
  }

export const config_multipart = {
    eaders: { 
        'Content-Type': 'multipart/form-data', 
      },
}