const wsuri = "ws://52.79.86.10:8964";

exports.wsuri = wsuri ;
