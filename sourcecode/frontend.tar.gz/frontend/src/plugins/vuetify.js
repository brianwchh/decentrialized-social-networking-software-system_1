import Vue from 'vue';
import Vuetify from 'vuetify/lib';

Vue.use(Vuetify,{
    theme: {
        dark : true
    }
});

export default new Vuetify({
});
