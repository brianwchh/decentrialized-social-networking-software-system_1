<template>
<div id="component-root">

  <div id="flex0">
    <div id="landpg">
      <img src="http://up.meipic.com/14/pic/48/38/af/4838afc9fa23535dd5b10606b10ec59b.jpg" alt="">
      <div class="right-element">
          <p class="_1989">1989.06.04</p>
          <p class="_198964">TianAnMen Square massacre, Bei Jing, China</p>
          <p class="_198964">Death: confidential, same as the death caused by the virus in 2020 </p>
          <p class="_64">We were not there, but we will remember CCP(Chinese Communist Party,the modern symbol for Nazi ver.2.0) sent army to massacre unarmed students who demanded for democracy, untill the day you can censorship every computer on earth</p>
          <a class="_64" href="https://www.youtube.com/watch?v=hA4iKSeijZI">click to watch the film by Arthur Kent</a>
      </div>
    </div>
  </div>

  <div id="flex1" >
    <div id="gridContainer-1">
      <div class="left-element">
        <div class="loop-images-container">

          <div class="image-container">
            <img src="https://www.mirrormedia.com.tw/assets/images/20191113163220-06bc0165230c6a509b4f48e9b92a4d2c-mobile.jpg" alt="" class="loop-image">
          </div>
          
          <div class="image-container">
            <img src="https://cdn.theatlantic.com/thumbor/GMQYQZ6H1cnYLJCUCKs_95_k_Qs=/0x0:4988x2804/720x405/media/img/mt/2019/06/RTS2IC2X/original.jpg" alt="" class="loop-image">
          </div>

          <div class="image-container">
            <img src="https://images.squarespace-cdn.com/content/v1/58ecfa82e3df284d3a13dd41/1572428151279-W1Y1QKTTO4KP02BX6N0C/ke17ZwdGBToddI8pDm48kG4sWXxm5MLGzYXxhI3Emb8UqsxRUqqbr1mOJYKfIPR7LoDQ9mXPOjoJoqy81S2I8N_N4V1vUb5AoIIIbLZhVYxCRW4BPu10St3TBAUQYVKcDFrDsapgIo0q8jUcW8rNPjhtZThjXNYUQzTwr7Xuxi1NR1RJqyZivqtN160e7oMj/000_1HD2V7.jpg" alt="" class="loop-image">
          </div>
          
          <div class="image-container">
            <img src="https://static01.nyt.com/images/2020/05/04/business/04PULITZER-CAPSULES-01/merlin_172184352_4c91b1b4-c154-4491-b103-d4f3ad061189-mediumSquareAt3X.jpg" alt="" class="loop-image">
          </div>

        </div>
      </div>
      <div class="right-element">
          <p class="_1989">2019</p>
          <p class="_198964"> Destroying HongKong's democracy,which was promised to keep it that way and never change,but again never keep their promise  </p>
          <p class="_198964">Death: over thounsand were killed for commiting suicide, many many more were sent to China,not knowing where they are...  </p>
      </div>
    </div>
  </div>

  <div id="gridContainer-2">
    <img class="army_child" src="https://img.ltn.com.tw/Upload/news/600/2019/07/30/phpEfaVoQ.jpg" alt="">
    <img class="redflag" src="https://obs.line-scdn.net/0h_uO0D5XyAFpySSh5PdV_DTwUBjULKhpSGDEXYAcfCnQHJRdaGjMKYhQTAj4AJ1tUMGkvbwI_DDM4JBlWLXkrbD8XPQwteR1NTioteT8oBHZffU4MSi1PNVNJXmINcUMLSy4KPQRAX21XKhQ/small" alt="">
    <p class="whoisnext">Who is next target ? </p>
    <p class="nextGen">Our young generation is ready ! </p>
    <p class="brianwash">A masterpiece of brain-wash !</p>
    <p class="ccpisnotChina">CCP !== China</p>
    <p class="ccpisnotChina1">CCP is NOT China</p>
    <p class="ccpisnotChina2">CCP is NOT China</p>
    <p class="ccpisnotChina3">CCP is NOT China</p>
  </div>

  <div id="flex3">
    <div id="gridContainer-3">
      <a href="https://edition.cnn.com/2019/12/19/health/sonic-attack-brain-study/index.html#:~:text=The%20%22sonic%20attacks%2C%22%20as,expanding%20a%20health%20alert%20there." 
        class="left">
        <img src="https://pbs.twimg.com/media/EZqwPg6WsAE72lT?format=jpg&name=large" alt="">
      </a>
      <div class="right">
        <p class="evidence">video that highly prove the Sonic attack on me from CCP </p>
        <div class="video_container">
          <iframe class="evidence_video"
            src="https://www.youtube.com/embed/Y0IqPZQVAnY">
          </iframe>
        </div>
        <p class="more"> more videos on my youtube channel </p>
        <p class="evidence"> two secret methods CCP uses to torture their targets </p>
        <p class="evidence2">(1) chemical gas emited near by your room</p>
        <p class="evidence2">(2) Sonic attack </p>
        <p class="evidence2"> both can cause insomnia problem</p>
      </div>
    </div>

  </div>


</div>

</template>

<script>


export default {
  name: 'Home',
  components: {
    
  },
   data () {
      return {
        
      }
    },

}
</script>


<style scoped>

#component-root {
  display: flex;
  flex-direction: column;
  align-items: center;
  /* background-color: rgb(207, 210, 212); */
}

#flex0 {
    position: relative;
    overflow: hidden;
    width: 100%;
    padding-top: 56.25%;
    display: flex;
    box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
}

#landpg {
  position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 0;
  display: grid;
  grid-template-columns: 75% 25%;
}

#landpg > img {
  height: 100%;
  width: 100%;
}

#landpg .right-element {
  width: 100%;
  height: 100%;
  /* grid-template-columns: 100%; */
  /* align-items: center; */
  background-color: rgba(54, 52, 46,1);
}

#landpg .right-element ._1989 {
  margin-top: 8%;
  color: red;
  font-weight:bolder;
  font-size: 3vw;
  text-align: center;
}

#landpg .right-element ._198964 {
  margin-top: 1%;
  color: yellow;
  font-weight:bold;
  font-size: 1.8vw;
  margin-left: 2vw;
  margin-right: 2vw;
}

#landpg .right-element ._64 {
  margin-left: 2vw;
  margin-right: 2vw;
  font-size: 1vw;
  color: white;
  word-wrap: break-word;
}


#gridContainer-1 .right-element ._1989 {
  margin-top: 8%;
  color: red;
  font-weight:bolder;
  font-size: 3vw;
  text-align: center;
}

#gridContainer-1 .right-element ._198964 {
  margin-top: 1%;
  color: yellow;
  font-weight:bold;
  font-size: 1.8vw;
  margin-left: 2vw;
  margin-right: 2vw;
}

#gridContainer-1 .right-element ._64 {
  margin-left: 2vw;
  margin-right: 2vw;
  font-size: 1vw;
  color: white;
  word-wrap: break-word;
}

#flex1 {
  margin-top: 4vw;
  position: relative;
  overflow: hidden;
  width: 100%;
  padding-top: 56.25%;
  display: flex;
  box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
}

#component-root #gridContainer-1 {
  position: absolute;
  top: 0;
  left: 0;
    width: 100%;
    height: 100%;
    border: 0;
  display: grid;
  grid-template-columns: 75% 25%;
  background-color: rgba(7, 79, 235,0.0);
  /* overflow: hidden; */
}


#component-root #gridContainer-1 .left-element {
  height: 100%;
  width: 100%;
  display: grid;
  grid-template-columns: 100%;
  overflow: hidden;
}

#component-root #gridContainer-1 .left-element > .loop-images-container {
  width: 400%;
  height: 100%;
  display: grid;
  grid-template-columns: 25% 25% 25% 25%;
  translate: (0,0);
  animation-name: loop ;
  animation-duration: 20s;
  animation-iteration-count: infinite;
  /* animation-timing-function: cubic-bezier(0.075, 0.82, 0.165, 1); */
}

@keyframes loop {
  0%,12% { transform: translate(0,0);}
  12.5%,24.5% { transform: translate(-25%,0);}
  25%,37%{ transform: translate(-50%,0);}
  37.5%,49.5% { transform: translate(-75%,0);}
  50%,62% { transform: translate(-75%,0);}
  62.5%,74.5% { transform: translate(-50%,0);}
  75%,87% { transform: translate(-25%,0);}
  87.5%,100% { transform: translate(0,0);}
}

#component-root #gridContainer-1 .left-element > .loop-images-container > .image-container {
  width: 100%;
  height: 100%;
  display: grid;
  grid-template-columns: 100%;
  overflow: hidden;
}

#component-root #gridContainer-1 .left-element > .loop-images-container > .image-container > img {
  width: 100%;
  height: 100%;
}

#component-root #gridContainer-1 .right-element {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  /* grid-template-columns: 100%; */
  /* align-items: center; */
  background-color: rgba(54, 52, 46,1);
}

#gridContainer-2 {
  margin-top: 4vw;
  position: relative;
  overflow: hidden;
  width: 100%;
  padding-top: 56.25%;
  box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
  display: flex;
}


#gridContainer-2 > .redflag {
    height:100%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0.4;
}

#gridContainer-2 > .army_child {
    height:30%;
    width: 30%;
    position: absolute;
    top: 0;
    right: 3%;
    opacity: 0.9;
    z-index: 2;
}

#gridContainer-2 > .whoisnext {
    position: absolute;
    font-weight: bold;
    top: 30%;
    right: 5%;
    font-size: 3vw;
    z-index: 3;
}

#gridContainer-2 > .nextGen {
    position: absolute;
    font-weight: bold;
    top: 40%;
    right: 5%;
    font-size: 2vw;
    z-index: 3;
}

#gridContainer-2 > .brianwash {
    position: absolute;
    font-weight: bold;
    top: 45%;
    right: 5%;
    font-size: 2vw;
    z-index: 3;
}

#gridContainer-2 > .ccpisnotChina {
    position: absolute;
    font-weight: bold;
    top: 60%;
    right: 50%;
    font-size: 2vw;
    z-index: 3;
}

#gridContainer-2 > .ccpisnotChina1 {
    position: absolute;
    font-weight: bold;
    top: 65%;
    right: 50%;
    font-size: 1.3vw;
    z-index: 3;
}

#gridContainer-2 > .ccpisnotChina2 {
    position: absolute;
    font-weight: bold;
    top: 68.5%;
    right: 50%;
    font-size: 1.1vw;
    z-index: 3;
}

#gridContainer-2 > .ccpisnotChina3 {
    position: absolute;
    font-weight: bold;
    top: 71.5%;
    right: 50%;
    font-size: 0.9vw;
    z-index: 3;
}


#flex3 {
  margin-top: 4vw;
  position: relative;
  overflow: hidden;
  width: 100%;
  padding-top: 56.25%;
  box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
}

#gridContainer-3 {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  display: grid;
  grid-template-columns: 70% 30%;
}

#gridContainer-3 .left {
    height:100%;
    width: 100%;
}

#gridContainer-3 .left img {
    height:100%;
    width: 100%;
}

#gridContainer-3 .right {
  width: 100%;
  height: 100%;
  /* grid-template-columns: 100%; */
  /* align-items: center; */
  background-color: rgba(54, 52, 46,1);
}

#gridContainer-3 > .right > .evidence {
    font-weight: bold;
    margin-top: 1vh;
    margin-right: 3vw;
    margin-left: 1vw;
    font-size: 1.2vw;
    z-index: 1;
    color: red;
}

#gridContainer-3 > .right > .video_container {
    position: relative;
    overflow: hidden;
    width: 100%;
    padding-top: 56.25%;
}

#gridContainer-3 > .right > .video_container > .evidence_video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 0;
}

#gridContainer-3 > .right > .evidence2 {
    margin-top: 1vh;
    margin-right: 3vw;
    margin-left: 1vw;
    font-size: 1.2vw;
    z-index: 1;
    color: white;
}

</style>