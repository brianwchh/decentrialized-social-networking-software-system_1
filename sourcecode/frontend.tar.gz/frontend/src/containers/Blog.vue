<template>
<div id="component-root">

    <div id="container_0">
        <div class="text_content">
            <p class="titl">家園在眼淚裡</p>
            <p class="con"></p>
            <p class="con">漂泊多時 </p>
            <p class="con">真希望能</p>
            <p class="con">安心寫寫代碼</p>
            <p class="con">胡亂塗鴉</p>
            <p class="con">偶爾附庸風雅</p>
            <p class="con"></p>
            <p class="con">一座農舍</p>
            <p class="con">一杯咖啡</p>
            <p class="con">一盞清茶</p>
            <p class="con">幾許綠色</p>
            <p class="con">蟬鳴鳥歡</p>
            <p class="con">伴着雨後泥土的清香</p>
            <p class="con"></p>
            <p class="con">或許還有那麼一彎小溪</p>
            <p class="con">牛郎的童年</p>
            <p class="con">依然還在那裡流淌著</p>
            <p class="con">只是依然還沒有</p>
            <p class="con">她的下凡</p>
            <p class="con"></p>
            <p class="con">遠離了那片土地</p>
            <p class="con">聽不到無聲的哭泣</p>
            <p class="con">簡陋的文字</p>
            <p class="con">寫不了十幾億</p>
            <p class="con">肚裡的眼淚</p>
        </div>

        <img src="https://www.mirrormedia.com.tw/assets/images/20191113163220-06bc0165230c6a509b4f48e9b92a4d2c-mobile.jpg" alt="">

    </div>

    <div id="container_1">
        <div class="text_content">
            <div class="col_0">
                <p class="titl">梅來眼泣</p>
                <p class="con"></p>
                <p class="con">天堂有兩位絕世佳人 </p>
                <p class="con">巾幗不讓鬚眉</p>
                <p class="con"></p>
                <p class="con">紅色的恐怖</p>
                <p class="con">恫嚇不了後來人</p>
                <p class="con">野火燒不盡</p>
                <p class="con">春風吹又生</p>
                <p class="con">只要還剩一片綠洲</p>
                <p class="con">華夏終返沃土</p>
                <p class="con"></p>
                <p class="con">只可惜</p>
                <p class="con">英雄不懂這病毒</p>
                <p class="con">帶走了幾代人的</p>
                <p class="con">回憶和渴望</p>
                <p class="con"></p>
                <p class="con">純真的人們</p>
                <p class="con">舉杯送走二戰</p>
                <p class="con">卻悄悄迎來了另一場</p>
                <p class="con">進化的戰爭</p>
                <p class="con">而這戰場</p>
                <p class="con">在你我的大腦裡</p>
                <p class="con">在子孫的紅色血液裡</p>
                <p class="con"></p>
                <p class="con">希特勒的殘暴</p>
                <p class="con">加速了世界的同盟</p>

            </div>

            <div class="col_1" >
                <p class="con">而偽善的病毒</p>
                <p class="con">韜光養晦</p>
                <p class="con">潤物細無聲</p>
                <p class="con">卻難以激起人類的免疫</p>
                <p class="con">直至牠們發展到足夠強大</p>
                <p class="con"></p>
                <p class="con">願此生</p>
                <p class="con">能迎來梅花遍地開的日子</p>
                <p class="con">那一天</p>
                <p class="con">我定會熱淚盈眶</p>
                <p class="con">嚎啕痛哭</p>
                <p class="con">所有的痛苦 委屈</p>
                <p class="con">都不負此生</p>
                <p class="con"></p>
                <p class="con">當我們踏上天堂路時</p>
                <p class="con">可以欣慰地告訴她們</p>
                <p class="con">你們的努力我們沒有辜負</p>
                <p class="con">英雄的熱血沒有白流</p>
                <p class="con"></p>
                <p class="con">我們銘記於心</p>
                <p class="con">終生感恩</p>
                
                
            </div>

            <div class="col_2" >
                <p class="con">牠們可以銷毀硬盤的記憶</p>
                <p class="con">卻永遠沒法銷毀我們的</p>
                <p class="con"></p>
                <p class="con">我們銘記於心</p>
                <p class="con">終生感恩</p>
                <p class="con">我們不會讓英雄心寒</p>
                <p class="con"></p>
                <p class="con">我們銘記於心</p>
                <p class="con">終生感恩</p>
                <p class="con"></p>
                <p class="con">永遠</p>
            </div>
            
            
        </div>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS5lJw7_ic8VoCCVNgmkLPPv4OzaTziH6udCEEhW-8k-d8G_wVD&usqp=CAU" alt="">

    </div>

    <div id="container_2">
        <p>憶父親</p>
        <p><br></p>
        <p>國小的時候</p>
        <p>經常喜歡在地上</p>
        <p>用粉筆做數學題</p>
        <p>然後等着他晚上回來誇我</p>
        <p>慢慢地</p>
        <p>就變成了他口中的書呆子</p>
        <p>而我也不知道爲啥要讀書 考試</p>
        <p>只懵懂地聽大人們說</p>
        <p>這是我們農村人改變命運的唯一途徑</p>
        <p>而他們也從來不問爲什麼要這樣活着</p>
        <p><br></p>
        <p>大家都是低頭 隨流</p>
        <p><br></p>
        <p>印象中</p>
        <p>他只打過我兩次</p>
        <p>一次是跟姐吵架</p>
        <p>吃了一記耳光</p>
        <p>一次是偷錢</p>
        <p>被吊着打</p>
        <p>長輩們在旁</p>
        <p>諄諄教誨：</p>
        <p>從小偷針 長大偷金呀</p>
        <p>之後的歲月裏</p>
        <p>也從沒敢偷摘別人地裏的東西</p>
        <p>只因記得媽媽說過</p>
        <p>吃自己的東西才不會被別人指着脊樑罵</p>
        <p>然而等鄉巴佬進城後發現</p>
        <p>大家都在比着彎道超車</p>
        <p>強盜 騙子搖身一變</p>
        <p>做着慈善 公益</p>
        <p>名節原來是可以買的</p>
        <p>而人們也是可以趨之若鹜的</p>
        <p>睜眼也是可以說瞎話的</p>
        <p><br></p>
        <p>我們迎來了最好的偷金爲王的時代</p>
        <p><br></p>
        <p>他有一手好木匠活</p>
        <p>也給村裏人修電器</p>
        <p>最懷念的就是</p>
        <p>跟他一起打魚的日子</p>
        <p>舊式的手搖電話機</p>
        <p>經他改造 升壓</p>
        <p>正負兩極分置於竹筏兩頭</p>
        <p>我一直搖</p>
        <p>魚兒就一條條往水面躍起</p>
        <p>他便一杆一杆把魚撈起</p>
        <p>有一次魚就在旁邊吃力地遊着</p>
        <p>我順手一抓</p>
        <p>卻被電得麻麻的</p>
        <p>這觸電的回憶</p>
        <p>好似依然還在昨日</p>
        <p>不過這種工具</p>
        <p>只能打沒有魚鱗的魚</p>
        <p>一種是黃骨魚</p>
        <p>另一種是只知鄉音卻不知其學名的魚</p>
        <p>如今似乎已經滅絕了</p>
        <p>那魚可是人間美味</p>
        <p><br></p>
        <p>可惜了</p>
        <p><br></p>
        <p>那時的水</p>
        <p>還是綠油油的清澈</p>
        <p>兩岸青山</p>
        <p>幾道灣</p>
        <p>水落山石出</p>
        <p>鳥鳴叢林間</p>
        <p>一葉輕舟</p>
        <p>兩父子</p>
        <p>風景甚是美麗 愜意</p>
        <p>然而</p>
        <p>大概是美景不能當飯吃的緣故</p>
        <p>攔腰建起了電站</p>
        <p>山腰修了長長的公路</p>
        <p>那幅畫從此消失在河底的淤泥深處</p>
        <p><br></p>
        <p>故鄉也只能在夢裏回顧</p>
        <p><br></p>
        <p>打小</p>
        <p>只見過他吹過一次口琴</p>
        <p>除了小孩唱的紅歌</p>
        <p>也似乎不會其他</p>
        <p>他能拉二胡 吹唢呐</p>
        <p>但都是上山下鄉時的陳年往事了</p>
        <p>他的婚姻歲月</p>
        <p>並無音樂</p>
        <p>只有無休止的爭吵</p>
        <p>酒成了他歲月的拐杖</p>
        <p>時代改變命運</p>
        <p>婚姻埋葬了彼此一生</p>
        <p>我經常躺在河邊的沙灘上</p>
        <p>仰望天空</p>
        <p>幻想着自己是別人家的幸福孩子</p>
        <p>直到他站在河邊</p>
        <p>扯着嗓子叫我回現實的家中吃飯</p>
        <p><br></p>
        <p>那時村裏的豬大多是放養的</p>
        <p>到喂食時間</p>
        <p>村民們在河邊叫着喚豬的鄉音：</p>
        <p>哦哇～ 哦哇～</p>
        <p>神奇的是</p>
        <p>這種一生只滿足於吃住的生靈</p>
        <p>居然能聽得懂各自主人的聲音</p>
        <p>不一會就哼哼唧唧從不遠處跑到跟前</p>
        <p>我們在沙灘玩耍時</p>
        <p>大人們也是到河邊呼喚着我們的乳名</p>
        <p>而後各自回家吃飯</p>
        <p><br></p>
        <p>我們都沒有選擇</p>
        <p><br></p>
        <p>長大後</p>
        <p>哥做了木匠</p>
        <p>而我喜歡上了電子</p>
        <p>唯獨我們的生活少了重要的音樂</p>
        <p><br></p>
        <p>父母不經意</p>
        <p>或者常常說的話</p>
        <p>經常會成爲兒女們想念他們的聲音</p>
        <p>而我常常想起他的就是：</p>
        <p><br></p>
        <p>在哪跌倒</p>
        <p>從哪站起來</p>
    </div>    


</div>
    
</template>

<script>
export default {

    name: "Blog",

    data: ()=>{
        return {

        }
    }
}
</script>

<style scoped>

#component-root {
  display: flex;
  flex-direction: column;
  align-items: center;
  /* background-color: rgb(207, 210, 212); */
}

#container_0 {
    width: 100%;
    padding-top: 56.25%;
    overflow: hidden;
    display: grid;
    position: relative;
    box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
}

#container_0 > .text_content {
    height:100%;
    width: 50%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
}


#container_0 > .text_content  > .titl {
    margin: 0;
    text-align: center;
    /* font-weight: bold; */
    font-size: 1.5vw;
    color: white;
}

#container_0 > .text_content  > .con {
    margin: 0;
    text-align: center;
    /* font-weight: bold; */
    font-size: 1.2vw;
    color: white;
}

#container_0 > .text_content  > p:empty {
    height: 1.2vw;
}

#container_0 > img {
    height:100%;
    width: 100%;
    top:0;
    left:0;
    position: absolute;
    opacity: 0.8;
}

#container_1 {
    width: 100%;
    padding-top: 56.25%;
    margin-top: 3% ;
    display: grid;
    position: relative;
    box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
}

#container_1 > .text_content {
    height:100%;
    width: 100%;
    display: grid;
    grid-template-columns: 33.3% 33.3% 33.3%;
    position: absolute;
    justify-items: center;
    align-items: center;
    top: 0;
    left: 0;
    z-index: 2;
}

#container_1 > .text_content > .col_0 {
    width: 100%;
    height: 90%;
    top: 0;
}

#container_1 > .text_content > .col_1 {
    width: 100%;
    height: 90%;
}

#container_1 > .text_content > .col_2 {
    width: 100%;
    height: 90%;
}

#container_1 > .text_content  .titl {
    margin: 0mm;
    font-size: 1.5vw;
    text-align: center;
    /* font-weight: bold; */
    /* color: white; */
}

#container_1 > .text_content  .con {
    margin: 0;
    font-size: 1.2vw;
    text-align: center;
    /* font-weight: bold; */
    /* color: white; */
}

#container_1 > .text_content   p:empty {
    height: 1.2vw;
}

#container_1  img {
    height:100%;
    width: 100%;
    top:0;
    left:0;
    position: absolute;
    opacity: 0.5;
}

#container_2 {
    width: 100%;
    margin-top: 3% ;
    margin-bottom: 3%;
    padding-top: 3%;
    padding-bottom: 3%;
    display: flex;
    box-shadow: 10px 10px 20px 5px rgba(57, 65, 60); 
    flex-direction: column;
}

#container_2 p {
    margin: 0;
    font-size: 1.5vw;
    text-align: center;
}

</style>